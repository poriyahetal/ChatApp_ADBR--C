package com.chat.kahochat;

import android.content.Intent;

import androidx.annotation.NonNull;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity extends FlutterActivity {
    private static  final String CHANNEL = "deepArChannel";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine){
        try{
            GeneratedPluginRegistrant.registerWith(flutterEngine);
            new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(),CHANNEL)
                    .setMethodCallHandler(((call, result) -> {
                        if ("openDeepAr".equals(call.method)) {
                            System.out.println("IN Platform channel");
                            startActivity(new Intent(this, CameraActivity.class));
                        }
                    }));
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }


}
